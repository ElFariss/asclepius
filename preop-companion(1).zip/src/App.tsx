import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  CheckCircle2, 
  ChevronRight, 
  Clock, 
  FileText, 
  Activity, 
  Calendar, 
  Wifi, 
  WifiOff, 
  TrendingUp, 
  User,
  ArrowLeft,
  Info,
  AlertCircle,
  Mail,
  ShieldAlert,
  ClipboardList,
  CheckCircle,
  Users,
  Plus,
  Settings,
  LogOut,
  Search,
  MoreVertical,
  Stethoscope,
  Lock,
  MessageSquare,
  Slash
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { cn } from './lib/utils';

// --- Types ---
type Role = 'patient' | 'doctor';
type Step = 'login' | 'register' | 'empty' | 'invite' | 'surgery-details' | 'tnc' | 'dashboard' | 'checklist' | 'progress';
type DoctorStep = 'login' | 'register' | 'dashboard' | 'patient-detail' | 'add-patient' | 'calendar-full';

interface Task {
  id: string;
  title: string;
  time: string;
  completed: boolean;
  category: 'medication' | 'exercise' | 'nutrition';
}

const INITIAL_TASKS: Task[] = [
  { id: '1', title: 'Take Protein Supplement', time: '08:00', completed: false, category: 'nutrition' },
  { id: '2', title: 'Breathing Exercises (10 min)', time: '10:00', completed: true, category: 'exercise' },
  { id: '3', title: 'Afternoon Walk', time: '16:00', completed: false, category: 'exercise' },
  { id: '4', title: 'Fast from 10:00 PM', time: '22:00', completed: false, category: 'nutrition' },
];

const PROGRESS_DATA = [
  { day: 'Mon', compliance: 85, risk: 12 },
  { day: 'Tue', compliance: 90, risk: 10 },
  { day: 'Wed', compliance: 75, risk: 15 },
  { day: 'Thu', compliance: 95, risk: 8 },
  { day: 'Fri', compliance: 100, risk: 5 },
  { day: 'Sat', compliance: 92, risk: 7 },
  { day: 'Sun', compliance: 98, risk: 6 },
];

const PATIENTS = [
  { id: 'p1', name: 'Budi Santoso', procedure: 'Cholecystectomy', compliance: 91, risk: 'Low', riskScore: 6, status: 'On Track' },
  { id: 'p2', name: 'Siti Aminah', procedure: 'Herniorrhaphy', compliance: 45, risk: 'High', riskScore: 18, status: 'Needs Intervention' },
  { id: 'p3', name: 'Agus Wijaya', procedure: 'Appendectomy', compliance: 78, risk: 'Medium', riskScore: 11, status: 'Warning' },
];

const PROTOCOLS = [
  { id: 'pr1', name: 'Standard Laparoscopic', category: 'General Surgery', tasks: 12 },
  { id: 'pr2', name: 'Enhanced Recovery (ERAS)', category: 'Digestive', tasks: 18 },
  { id: 'pr3', name: 'Geriatric Specialized', category: 'General', tasks: 15 },
];

// --- Doctor Components ---

const LoginScreen = ({ onLogin, onRegister, role, setRole }: { onLogin: () => void; onRegister: () => void; role: Role; setRole: (role: Role) => void }) => (
  <div className="p-8 flex flex-col h-full bg-white">
    <div className="mt-12 mb-8 flex flex-col items-center">
      <div className={cn(
        "w-20 h-20 rounded-[2rem] flex items-center justify-center text-white shadow-xl mb-4 transition-all duration-500",
        role === 'doctor' ? "bg-blue-600 shadow-blue-200" : "bg-blue-500 shadow-blue-100"
      )}>
        {role === 'doctor' ? <Stethoscope size={40} /> : <User size={40} />}
      </div>
      <h1 className="text-2xl font-display font-bold text-slate-900">PreOp {role === 'doctor' ? 'Doctor' : 'Patient'}</h1>
      <p className="text-slate-500 text-sm">{role === 'doctor' ? 'Patient Management Portal' : 'Your Surgery Preparation Companion'}</p>
    </div>

    {/* Role Switcher */}
    <div className="flex bg-slate-100 p-1 rounded-2xl mb-8">
      <button 
        onClick={() => setRole('patient')}
        className={cn(
          "flex-1 py-3 rounded-xl text-xs font-bold transition-all",
          role === 'patient' ? "bg-white text-blue-600 shadow-sm" : "text-slate-500"
        )}
      >
        Patient
      </button>
      <button 
        onClick={() => setRole('doctor')}
        className={cn(
          "flex-1 py-3 rounded-xl text-xs font-bold transition-all",
          role === 'doctor' ? "bg-white text-blue-600 shadow-sm" : "text-slate-500"
        )}
      >
        Doctor
      </button>
    </div>

    <div className="space-y-4">
      <div>
        <label className="text-xs font-bold text-slate-400 uppercase mb-1 block">Email Address</label>
        <div className="relative">
          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="email" 
            placeholder={role === 'doctor' ? "dr.andi@hospital.com" : "patient@example.com"}
            className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
        </div>
      </div>
      <div>
        <label className="text-xs font-bold text-slate-400 uppercase mb-1 block">Password</label>
        <div className="relative">
          <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="password" 
            placeholder="••••••••"
            className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
        </div>
      </div>
    </div>

    <button 
      onClick={onLogin}
      className="mt-8 w-full bg-blue-600 text-white py-4 rounded-2xl font-semibold shadow-lg shadow-blue-200 active:scale-95 transition-transform"
    >
      Login to Dashboard
    </button>

    <div className="mt-6 text-center">
      <p className="text-sm text-slate-500">
        Don't have an account?{' '}
        <button onClick={onRegister} className="text-blue-600 font-bold hover:underline">
          Register Now
        </button>
      </p>
    </div>
    
    <p className="mt-auto text-center text-[10px] text-slate-400">
      {role === 'doctor' 
        ? "Session will automatically end after 30 minutes of inactivity." 
        : "Your data is encrypted and stored securely."}
    </p>
  </div>
);

const RegisterScreen = ({ onRegister, onLogin, role, setRole }: { onRegister: () => void; onLogin: () => void; role: Role; setRole: (role: Role) => void }) => (
  <div className="p-8 flex flex-col h-full bg-white">
    <div className="mt-8 mb-8 flex flex-col items-center">
      <div className={cn(
        "w-16 h-16 rounded-[1.5rem] flex items-center justify-center text-white shadow-xl mb-4 transition-all duration-500",
        role === 'doctor' ? "bg-blue-600 shadow-blue-200" : "bg-blue-500 shadow-blue-100"
      )}>
        {role === 'doctor' ? <Stethoscope size={32} /> : <User size={32} />}
      </div>
      <h1 className="text-xl font-display font-bold text-slate-900">Create Account</h1>
      <p className="text-slate-500 text-sm">Join PreOp as a {role}</p>
    </div>

    {/* Role Switcher */}
    <div className="flex bg-slate-100 p-1 rounded-2xl mb-6">
      <button 
        onClick={() => setRole('patient')}
        className={cn(
          "flex-1 py-2.5 rounded-xl text-[10px] font-bold transition-all",
          role === 'patient' ? "bg-white text-blue-600 shadow-sm" : "text-slate-500"
        )}
      >
        Patient
      </button>
      <button 
        onClick={() => setRole('doctor')}
        className={cn(
          "flex-1 py-2.5 rounded-xl text-[10px] font-bold transition-all",
          role === 'doctor' ? "bg-white text-blue-600 shadow-sm" : "text-slate-500"
        )}
      >
        Doctor
      </button>
    </div>

    <div className="space-y-4 overflow-y-auto pr-1">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">First Name</label>
          <input 
            type="text" 
            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
        </div>
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">Last Name</label>
          <input 
            type="text" 
            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
        </div>
      </div>
      <div>
        <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">Email Address</label>
        <input 
          type="email" 
          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
        />
      </div>
      {role === 'doctor' && (
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">Medical License Number</label>
          <input 
            type="text" 
            placeholder="STR / License ID"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
          />
        </div>
      )}
      <div>
        <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">Password</label>
        <input 
          type="password" 
          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
        />
      </div>
      <div>
        <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">Confirm Password</label>
        <input 
          type="password" 
          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
        />
      </div>
    </div>

    <button 
      onClick={onRegister}
      className="mt-6 w-full bg-blue-600 text-white py-4 rounded-2xl font-semibold shadow-lg shadow-blue-200 active:scale-95 transition-transform"
    >
      Create Account
    </button>

    <div className="mt-4 text-center">
      <p className="text-sm text-slate-500">
        Already have an account?{' '}
        <button onClick={onLogin} className="text-blue-600 font-bold hover:underline">
          Login
        </button>
      </p>
    </div>
  </div>
);

const DoctorDashboardScreen = ({ 
  onSelectPatient, 
  onAddPatient,
  onLogout 
}: { 
  onSelectPatient: (p: any) => void; 
  onAddPatient: () => void;
  onLogout: () => void;
}) => (
  <div className="flex flex-col h-full bg-slate-50">
    <div className="bg-white p-6 pb-8 rounded-b-[3rem] shadow-sm border-b border-slate-100">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-blue-100">
            <img src="https://picsum.photos/seed/doctor/100/100" alt="Dr" className="w-full h-full object-cover" />
          </div>
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase">Good Morning</p>
            <p className="font-display font-bold text-slate-900">Dr. Andi Setiawan</p>
          </div>
        </div>
        <button onClick={onLogout} className="p-2 text-slate-400 hover:text-red-500 transition-colors">
          <LogOut size={20} />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-200">
          <Users size={20} className="mb-2 opacity-60" />
          <p className="text-2xl font-display font-bold">24</p>
          <p className="text-[10px] uppercase font-bold opacity-80">Active Patients</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-2xl border border-yellow-100 shadow-sm">
          <AlertCircle size={20} className="mb-2 text-yellow-600" />
          <p className="text-2xl font-display font-bold text-slate-900">3</p>
          <p className="text-[10px] uppercase font-bold text-yellow-700">Needs Intervention</p>
        </div>
      </div>
    </div>

    <div className="p-6 space-y-6 flex-1 overflow-y-auto">
      <div className="flex items-center justify-between">
        <h3 className="font-display font-bold text-lg">Patient List</h3>
        <button onClick={onAddPatient} className="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center shadow-lg shadow-blue-100">
          <Plus size={20} />
        </button>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
        <input 
          placeholder="Search name or procedure..."
          className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-10 pr-4 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {PATIENTS.map(p => (
          <motion.div 
            key={p.id}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelectPatient(p)}
            className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between cursor-pointer group hover:shadow-md transition-shadow"
          >
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold",
                p.risk === 'High' ? 'bg-red-500' : p.risk === 'Medium' ? 'bg-yellow-500' : 'bg-blue-600'
              )}>
                {p.riskScore}
              </div>
              <div>
                <p className="text-sm font-bold text-slate-900">{p.name}</p>
                <p className="text-[10px] text-slate-400 font-medium">{p.procedure}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-slate-900">{p.compliance}%</p>
              <p className={cn(
                "text-[10px] font-bold uppercase tracking-wider",
                p.risk === 'High' ? 'text-red-500' : p.risk === 'Medium' ? 'text-yellow-600' : 'text-blue-600'
              )}>{p.status}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </div>
);

const DoctorPatientDetailScreen = ({ patient, onBack, onExpandCalendar }: { patient: any; onBack: () => void; onExpandCalendar: () => void }) => {
  const [decision, setDecision] = useState<'none' | 'go' | 'no-go'>('none');
  const [showAddMenu, setShowAddMenu] = useState(false);

  // Mock calendar data for the current week
  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const today = 3; // Thursday

  const patientTasks = [
    { id: '1', title: 'Morning Medication', time: '08:00', completed: true },
    { id: '2', title: 'Breathing Exercise', time: '10:00', completed: true },
    { id: '3', title: 'Walk 15 mins', time: '16:00', completed: false },
    { id: '4', title: 'Evening Medication', time: '20:00', completed: false },
  ];

  return (
    <div className="flex flex-col h-full bg-white relative">
      <div className="p-6 flex items-center justify-between border-b border-slate-100">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h2 className="text-lg font-display font-bold">{patient.name}</h2>
            <p className="text-[10px] text-slate-400 font-bold uppercase">{patient.procedure}</p>
          </div>
        </div>
        <button className="p-2 text-slate-400">
          <MoreVertical size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-8">
            {/* Real-time Monitoring */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Compliance</p>
                <div className="flex items-end gap-2">
                  <p className="text-2xl font-display font-bold text-blue-600">{patient.compliance}%</p>
                  <TrendingUp size={16} className="text-green-500 mb-1" />
                </div>
              </div>
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Risk Score</p>
                <div className="flex items-end gap-2">
                  <p className={cn(
                    "text-2xl font-display font-bold",
                    patient.risk === 'High' ? 'text-red-500' : 'text-blue-600'
                  )}>{patient.riskScore}</p>
                  <Activity size={16} className="text-slate-300 mb-1" />
                </div>
              </div>
            </div>

            {/* Compliance Trend */}
            <div>
              <h3 className="font-bold text-sm mb-4 flex items-center gap-2">
                <TrendingUp size={16} className="text-blue-600" />
                Last 7 Days Compliance Trend
              </h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={PROGRESS_DATA}>
                    <Area type="monotone" dataKey="compliance" stroke="#2563eb" strokeWidth={2} fill="#dbeafe" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Intervention Section */}
            {patient.risk === 'High' && (
              <div className="bg-red-50 border border-red-100 rounded-2xl p-4">
                <div className="flex gap-3 mb-4">
                  <AlertCircle className="text-red-500 shrink-0" />
                  <div>
                    <p className="text-sm font-bold text-red-900">High Risk Warning</p>
                    <p className="text-xs text-red-700 leading-relaxed">
                      Patient compliance is below 50%. Risk of complications is significantly increased.
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 bg-white border border-red-200 text-red-600 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2">
                    <MessageSquare size={14} /> Contact Patient
                  </button>
                  <button className="flex-1 bg-white border border-red-200 text-red-600 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2">
                    <Settings size={14} /> Modify Protocol
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-8">
            {/* Calendar View */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm flex items-center gap-2">
                  <Calendar size={16} className="text-blue-600" />
                  Task Tracker
                </h3>
                <button 
                  onClick={onExpandCalendar}
                  className="text-[10px] font-bold text-blue-600 uppercase hover:underline"
                >
                  View Full Month
                </button>
              </div>
              
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 relative">
                <div className="grid grid-cols-7 gap-2 mb-4">
                  {weekDays.map((day, i) => (
                    <div key={day} className="text-center">
                      <p className="text-[10px] font-bold text-slate-400 uppercase mb-2">{day}</p>
                      <div className={cn(
                        "w-8 h-8 mx-auto rounded-full flex items-center justify-center text-xs font-bold transition-all",
                        i === today ? "bg-blue-600 text-white shadow-md shadow-blue-100" : "bg-white text-slate-600 border border-slate-100"
                      )}>
                        {10 + i}
                      </div>
                      {/* Compliance dots */}
                      <div className="flex justify-center gap-0.5 mt-1">
                        <div className={cn("w-1 h-1 rounded-full", i < today ? "bg-green-500" : "bg-slate-200")} />
                        <div className={cn("w-1 h-1 rounded-full", i < today ? "bg-green-500" : "bg-slate-200")} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Next Appointment */}
                <div className="bg-white p-3 rounded-xl border border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                      <Clock size={16} />
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">Next Appointment</p>
                      <p className="text-xs font-bold text-slate-900">Tomorrow, 09:00 AM</p>
                    </div>
                  </div>
                  <ChevronRight size={16} className="text-slate-300" />
                </div>

                {/* FAB for adding items */}
                <div className="absolute -bottom-4 -right-2">
                  <div className="relative">
                    <AnimatePresence>
                      {showAddMenu && (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.8, y: 10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.8, y: 10 }}
                          className="absolute bottom-16 right-0 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 w-40 z-20"
                        >
                          <button className="w-full text-left p-3 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-2">
                            <ClipboardList size={14} className="text-blue-600" /> Add Task
                          </button>
                          <button className="w-full text-left p-3 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-2">
                            <Calendar size={14} className="text-blue-600" /> Appointment
                          </button>
                          <button className="w-full text-left p-3 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 flex items-center gap-2">
                            <Activity size={14} className="text-blue-600" /> Medicine
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                    <motion.button 
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setShowAddMenu(!showAddMenu)}
                      className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-200 z-30"
                    >
                      <Plus size={24} className={cn("transition-transform duration-300", showAddMenu && "rotate-45")} />
                    </motion.button>
                  </div>
                </div>
              </div>
            </div>

            {/* Today's Tasks */}
            <div className="space-y-4">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <ClipboardList size={16} className="text-blue-600" />
                Today's Patient Tasks
              </h3>
              <div className="space-y-3">
                {patientTasks.map(task => (
                  <div key={task.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-6 h-6 rounded-lg flex items-center justify-center",
                        task.completed ? "bg-green-100 text-green-600" : "bg-slate-100 text-slate-400"
                      )}>
                        {task.completed ? <CheckCircle size={14} /> : <Clock size={14} />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{task.title}</p>
                        <p className="text-[10px] text-slate-400 font-medium">{task.time}</p>
                      </div>
                    </div>
                    <div className={cn(
                      "px-2 py-1 rounded-md text-[10px] font-bold uppercase",
                      task.completed ? "bg-green-50 text-green-700" : "bg-slate-50 text-slate-400"
                    )}>
                      {task.completed ? 'Done' : 'Pending'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Decision Section */}
        <div className="pt-8 mt-8 border-t border-slate-100">
          <h3 className="font-bold text-sm mb-4">Surgery Decision (Go/No-Go)</h3>
          <div className="flex gap-4">
            <button 
              onClick={() => setDecision('go')}
              className={cn(
                "flex-1 py-4 rounded-2xl font-bold text-sm transition-all flex flex-col items-center gap-1",
                decision === 'go' ? "bg-green-600 text-white shadow-lg shadow-green-100" : "bg-slate-50 text-slate-400 border border-slate-100"
              )}
            >
              <CheckCircle size={20} />
              Proceed Surgery
            </button>
            <button 
              onClick={() => setDecision('no-go')}
              className={cn(
                "flex-1 py-4 rounded-2xl font-bold text-sm transition-all flex flex-col items-center gap-1",
                decision === 'no-go' ? "bg-red-600 text-white shadow-lg shadow-red-100" : "bg-slate-50 text-slate-400 border border-slate-100"
              )}
            >
              <Slash size={20} />
              Postpone / Cancel
            </button>
          </div>
          <p className="mt-4 text-[10px] text-slate-400 text-center italic">
            * Final decision remains with the doctor's clinical judgment. Risk scores are for reference only.
          </p>
        </div>
      </div>
    </div>
  );
};

const DoctorAddPatientScreen = ({ onBack, onComplete }: { onBack: () => void; onComplete: () => void }) => {
  const [step, setStep] = useState(1);

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-6 flex items-center gap-4 border-b border-slate-100">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-xl font-display font-bold">Add New Patient</h2>
      </div>

      <div className="p-6 space-y-6 flex-1 overflow-y-auto">
        {step === 1 ? (
          <div className="max-w-2xl mx-auto w-full space-y-8">
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Patient Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input placeholder="Patient Full Name" className="w-full bg-slate-50 border border-slate-200 rounded-xl py-4 px-4 text-sm" />
                <input placeholder="Medical Record Number" className="w-full bg-slate-50 border border-slate-200 rounded-xl py-4 px-4 text-sm" />
                <input type="date" className="w-full bg-slate-50 border border-slate-200 rounded-xl py-4 px-4 text-sm md:col-span-2" />
              </div>
            </div>
            <button 
              onClick={() => setStep(2)}
              className="w-full bg-blue-600 text-white py-4 rounded-2xl font-semibold shadow-lg shadow-blue-200"
            >
              Choose Protocol
            </button>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto w-full space-y-8">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Select Preparation Protocol</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {PROTOCOLS.map(p => (
                <div key={p.id} className="p-4 rounded-2xl border border-slate-200 hover:border-blue-500 cursor-pointer transition-all bg-white shadow-sm hover:shadow-md">
                  <p className="font-bold text-slate-900">{p.name}</p>
                  <p className="text-xs text-slate-500">{p.category} • {p.tasks} Tasks</p>
                </div>
              ))}
              <div className="p-4 rounded-2xl border border-dashed border-slate-300 text-slate-400 flex items-center justify-center gap-2 text-sm font-medium hover:bg-slate-50 cursor-pointer transition-colors">
                <Plus size={18} /> Create New Protocol
              </div>
            </div>
            <button 
              onClick={onComplete}
              className="w-full bg-blue-600 text-white py-4 rounded-2xl font-semibold shadow-lg shadow-blue-200"
            >
              Send Invitation to Patient
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// --- Components ---

const EmptyHomeScreen = ({ onOpenMail }: { onOpenMail: () => void }) => (
  <div className="min-h-screen flex flex-col items-center justify-center p-8 bg-white">
    <div className="text-center space-y-8">
      <div className="relative flex justify-center">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onOpenMail}
          className="w-32 h-32 bg-white rounded-full shadow-2xl flex items-center justify-center text-blue-600 relative z-10 border border-slate-100"
        >
          <div className="flex items-center justify-center w-full h-full">
            <Mail size={48} strokeWidth={1.5} />
          </div>
          <span className="absolute top-4 right-4 w-5 h-5 bg-red-500 rounded-full border-4 border-white animate-pulse" />
        </motion.button>
        <div className="absolute inset-0 bg-blue-400/20 rounded-full blur-3xl animate-pulse scale-150" />
      </div>
      <div>
        <h2 className="text-2xl font-display font-bold text-slate-900">No Schedule Yet</h2>
        <p className="text-slate-500 text-sm mt-2 max-w-[240px] mx-auto">Tap the mail icon to view invitations from your doctor.</p>
      </div>
    </div>
  </div>
);

const InviteScreen = ({ onAccept, onBack }: { onAccept: () => void; onBack: () => void }) => (
  <div className="p-6 flex flex-col h-full bg-white">
    <button onClick={onBack} className="mb-6 p-2 -ml-2 hover:bg-slate-100 rounded-full transition-colors w-fit">
      <ArrowLeft size={20} />
    </button>
    <div className="mt-4 mb-8 flex justify-center">
      <div className="w-20 h-20 bg-blue-100 rounded-3xl flex items-center justify-center text-blue-600">
        <Bell size={40} />
      </div>
    </div>
    <h1 className="text-2xl font-display font-bold text-center mb-2">Surgery Invitation</h1>
    <p className="text-slate-500 text-center mb-8">
      Dr. Andi Setiawan has registered you for an upcoming surgical procedure.
    </p>
    
    <div className="bg-slate-50 rounded-2xl p-4 mb-8 border border-slate-100">
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-sm overflow-hidden">
          <img 
            src="https://picsum.photos/seed/doctor/200/200" 
            alt="Doctor" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div>
          <p className="text-sm font-semibold">Dr. Andi Setiawan</p>
          <p className="text-xs text-slate-500">General Surgery Specialist</p>
        </div>
      </div>
      <div className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-slate-500">Procedure:</span>
          <span className="font-medium">Laparoscopic Cholecystectomy</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-slate-500">Date:</span>
          <span className="font-medium">April 15, 2026</span>
        </div>
      </div>
    </div>

    <button 
      onClick={onAccept}
      className="mt-auto w-full bg-blue-600 text-white py-4 rounded-2xl font-semibold shadow-lg shadow-blue-200 active:scale-95 transition-transform"
    >
      Open Medical Consent
    </button>
  </div>
);

const SurgeryDetailsScreen = ({ onNext }: { onNext: () => void }) => (
  <div className="p-6 flex flex-col h-full bg-white">
    <div className="flex items-center gap-2 mb-8">
      <div className="w-1.5 h-6 bg-blue-600 rounded-full" />
      <h2 className="text-xl font-display font-bold">Surgery Details</h2>
    </div>

    <div className="flex gap-4 mb-8">
      <div className="w-24 h-32 rounded-2xl overflow-hidden shadow-md shrink-0">
        <img 
          src="https://picsum.photos/seed/doctor/400/600" 
          alt="Doctor" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      </div>
      <div className="flex flex-col justify-center">
        <p className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-1">Attending Physician</p>
        <p className="text-lg font-bold text-slate-900">Dr. Andi Setiawan</p>
        <p className="text-sm text-slate-500">Digestive & Oncology Surgery</p>
        <div className="mt-2 flex gap-1">
          {[1, 2, 3, 4, 5].map(i => (
            <div key={i} className="w-1 h-1 rounded-full bg-blue-200" />
          ))}
        </div>
      </div>
    </div>

    <div className="space-y-6 flex-1">
      <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
        <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Activity size={18} className="text-blue-600" />
          Medical Procedure
        </h3>
        <p className="text-sm text-slate-600 leading-relaxed">
          Laparoscopic Cholecystectomy is a minimally invasive surgical procedure to remove the gallbladder. The doctor will make 3-4 small incisions (5-10mm) in the abdomen to insert a camera and surgical instruments.
        </p>
      </div>

      <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
        <h3 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Clock size={18} className="text-blue-600" />
          Estimated Time
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-slate-400">Surgery Duration</p>
            <p className="text-sm font-bold">60 - 90 Minutes</p>
          </div>
          <div>
            <p className="text-xs text-slate-400">Hospital Stay</p>
            <p className="text-sm font-bold">1 - 2 Days</p>
          </div>
        </div>
      </div>
    </div>

    <button 
      onClick={onNext}
      className="mt-8 w-full bg-slate-900 text-white py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 active:scale-95 transition-transform"
    >
      Continue to Requirements <ChevronRight size={20} />
    </button>
  </div>
);

const TNCScreen = ({ onComplete }: { onComplete: () => void }) => {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="p-6 flex flex-col h-full bg-white">
      <div className="flex items-center gap-2 mb-6">
        <ShieldAlert className="text-red-600" />
        <h2 className="text-xl font-display font-bold">Legal Terms & Conditions</h2>
      </div>

      <div className="space-y-6 flex-1 overflow-y-auto pr-1">
        {/* Surgery Checklist Preview */}
        <div className="bg-blue-50 rounded-2xl p-5 border border-blue-100">
          <h3 className="font-bold text-blue-900 mb-3 flex items-center gap-2">
            <ClipboardList size={18} />
            Mandatory Preparation List
          </h3>
          <p className="text-xs text-blue-700 mb-4">
            You are required to complete the following tasks daily before surgery:
          </p>
          <ul className="space-y-2">
            {['Fast 8 hours before procedure', 'Daily breathing exercises', 'High protein intake', 'Avoid smoking & alcohol'].map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-xs font-medium text-blue-800">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        {/* Legal TNC */}
        <div className="bg-red-50 rounded-2xl p-5 border-2 border-red-500 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-2 opacity-10">
            <ShieldAlert size={80} />
          </div>
          <h3 className="font-bold text-red-900 mb-3 uppercase tracking-tight">Legal Liability Statement</h3>
          <div className="text-xs text-red-800 space-y-3 leading-relaxed">
            <p className="font-bold">IMPORTANT: PLEASE READ CAREFULLY</p>
            <p>
              By agreeing to this document, you consciously accept that the success of the surgery depends heavily on your compliance with the provided medical preparation checklist.
            </p>
            <p className="bg-red-100 p-2 rounded-lg border border-red-200">
              <span className="font-bold">Liability Clause:</span> If medical complications occur due to patient non-compliance with pre-surgical instructions (checklist), the hospital and doctor <span className="underline">cannot be held legally liable</span>. All risks are the personal responsibility of the patient.
            </p>
            <p>
              Dishonesty in completing the checklist can endanger your life during anesthesia and surgery.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-6 space-y-4">
        <label className="flex items-start gap-3 cursor-pointer p-3 rounded-xl bg-slate-50 border border-slate-200">
          <input 
            type="checkbox" 
            className="mt-1 w-5 h-5 rounded border-slate-300 text-red-600 focus:ring-red-500" 
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
          />
          <span className="text-xs font-medium text-slate-700 leading-tight">
            I understand and accept full legal responsibility for my surgical preparation compliance.
          </span>
        </label>

        <button 
          disabled={!agreed}
          onClick={onComplete}
          className={cn(
            "w-full py-4 rounded-2xl font-semibold transition-all",
            agreed 
              ? "bg-red-600 text-white shadow-lg shadow-red-200" 
              : "bg-slate-200 text-slate-400 cursor-not-allowed"
          )}
        >
          I Agree & Accept Responsibility
        </button>
      </div>
    </div>
  );
};

const DashboardScreen = ({ onShowChecklist, onShowProgress, onLogout }: { onShowChecklist: () => void; onShowProgress: () => void; onLogout: () => void }) => {
  const [isOnline, setIsOnline] = useState(true);

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {/* Header */}
      <div className="bg-white p-6 pb-8 rounded-b-[3rem] shadow-sm border-b border-slate-100">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-200">
              <User size={24} />
            </div>
            <div>
              <p className="text-xs text-slate-400 font-medium">Registered Patient</p>
              <p className="font-display font-bold text-slate-900">Budi Santoso</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsOnline(!isOnline)}
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider transition-colors",
                isOnline ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
              )}
            >
              <div className={cn("w-1.5 h-1.5 rounded-full", isOnline ? "bg-green-500" : "bg-red-500")} />
              {isOnline ? 'Online' : 'Offline'}
            </button>
            <button onClick={onLogout} className="p-2 text-slate-400 hover:text-red-500 transition-colors">
              <LogOut size={18} />
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex justify-between items-end">
            <div>
              <h2 className="text-3xl font-display font-bold text-slate-900">12 Days</h2>
              <p className="text-sm text-slate-500">Until Your Surgery</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-blue-600 mb-1">Compliance</p>
              <p className="text-xl font-display font-bold text-slate-900">91%</p>
            </div>
          </div>
          
          <div className="h-48 w-full -mx-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={PROGRESS_DATA}>
                <defs>
                  <linearGradient id="dashComp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="compliance" stroke="#2563eb" strokeWidth={3} fill="url(#dashComp)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Cards */}
      <div className="p-6 space-y-4 -mt-6">
        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={onShowChecklist}
          className="w-full bg-white p-6 rounded-[2rem] shadow-xl shadow-slate-200/50 border border-slate-100 flex items-center justify-between group"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <ClipboardList size={28} />
            </div>
            <div className="text-left">
              <h3 className="font-display font-bold text-slate-900">Daily Checklist</h3>
              <p className="text-xs text-slate-500">2 of 4 tasks completed today</p>
            </div>
          </div>
          <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
            <ChevronRight size={20} />
          </div>
        </motion.button>

        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={onShowProgress}
            className="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm text-left group"
          >
            <TrendingUp className="text-yellow-500 mb-3 group-hover:scale-110 transition-transform" size={24} />
            <p className="text-xs text-slate-500 font-medium">Risk Trend</p>
            <p className="text-sm font-bold text-slate-900">Very Low</p>
          </button>
          <div className="bg-yellow-50 p-5 rounded-[2rem] border border-yellow-100 shadow-sm text-left">
            <Activity className="text-yellow-600 mb-3" size={24} />
            <p className="text-xs text-yellow-700 font-medium">Compliance Streak</p>
            <p className="text-sm font-bold text-yellow-900">5 Days 🔥</p>
          </div>
        </div>

        <div className="bg-blue-600 p-6 rounded-[2rem] text-white flex items-center justify-between shadow-lg shadow-blue-200">
          <div>
            <p className="text-xs opacity-80 mb-1">Last Consultation</p>
            <p className="font-bold">Yesterday, 14:20</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
            <Activity size={20} />
          </div>
        </div>
      </div>
    </div>
  );
};

const ChecklistScreen = ({ onBack }: { onBack: () => void }) => {
  const [tasks, setTasks] = useState(INITIAL_TASKS);

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const completedCount = tasks.filter(t => t.completed).length;

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-6 flex items-center justify-between border-b border-slate-100">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-xl font-display font-bold">Daily Checklist</h2>
        </div>
        <div className="bg-blue-50 px-3 py-1 rounded-full">
          <p className="text-xs font-bold text-blue-600">{completedCount}/{tasks.length}</p>
        </div>
      </div>

      <div className="p-6 space-y-4 overflow-y-auto">
        <div className="bg-slate-50 p-4 rounded-2xl flex gap-3 mb-4">
          <AlertCircle className="text-blue-500 shrink-0" size={20} />
          <p className="text-xs text-slate-600 leading-relaxed">
            Please fill out this checklist honestly. Non-compliance can increase the risk of surgical complications.
          </p>
        </div>

        {tasks.map((task) => (
          <motion.div 
            key={task.id}
            layout
            onClick={() => toggleTask(task.id)}
            className={cn(
              "p-5 rounded-2xl border transition-all cursor-pointer flex items-center gap-4",
              task.completed 
                ? "bg-yellow-50 border-yellow-100" 
                : "bg-white border-slate-200 shadow-sm"
            )}
          >
            <div className={cn(
              "w-8 h-8 rounded-xl border-2 flex items-center justify-center transition-all",
              task.completed ? "bg-yellow-400 border-yellow-400 scale-110" : "border-slate-300"
            )}>
              {task.completed && <CheckCircle size={20} className="text-yellow-900" />}
            </div>
            <div className="flex-1">
              <p className={cn("font-bold text-slate-900 transition-all", task.completed && "text-yellow-900 opacity-60")}>
                {task.title}
              </p>
              <div className="flex items-center gap-3 mt-1">
                <p className="text-[10px] uppercase tracking-wider font-bold text-slate-400 flex items-center gap-1">
                  <Clock size={10} /> {task.time}
                </p>
                <div className="w-1 h-1 rounded-full bg-slate-300" />
                <p className="text-[10px] uppercase tracking-wider font-bold text-blue-500">
                  {task.category}
                </p>
              </div>
            </div>
          </motion.div>
        ))}

        <div className="pt-8 text-center">
          <p className="text-xs text-slate-400 italic">
            The system will automatically record your task completion time.
          </p>
        </div>
      </div>
    </div>
  );
};

const ProgressScreen = ({ onBack }: { onBack: () => void }) => (
  <div className="flex flex-col h-full bg-white">
    <div className="p-6 flex items-center gap-4 border-b border-slate-100">
      <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
        <ArrowLeft size={20} />
      </button>
      <h2 className="text-xl font-display font-bold">Compliance Analysis</h2>
    </div>

    <div className="p-6 space-y-8 overflow-y-auto">
      {/* Compliance Chart */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold flex items-center gap-2">
            <TrendingUp size={18} className="text-blue-600" />
            Daily Compliance (%)
          </h3>
          <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md">
            Avg: 91%
          </span>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={PROGRESS_DATA}>
              <defs>
                <linearGradient id="colorComp" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
              <YAxis hide domain={[0, 100]} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Area type="monotone" dataKey="compliance" stroke="#2563eb" strokeWidth={3} fillOpacity={1} fill="url(#colorComp)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Risk Score Chart */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold flex items-center gap-2 text-red-500">
            <Activity size={18} />
            Risk Score Trend
          </h3>
          <span className="text-xs font-bold text-red-500 bg-red-50 px-2 py-1 rounded-md">
            Low Risk
          </span>
        </div>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={PROGRESS_DATA}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#94a3b8' }} />
              <YAxis hide domain={[0, 20]} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Line type="monotone" dataKey="risk" stroke="#ef4444" strokeWidth={3} dot={{ r: 4, fill: '#ef4444' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
          <p className="text-xs text-slate-500 mb-1 font-medium">Total Days</p>
          <p className="text-xl font-bold text-slate-900">12/180</p>
        </div>
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
          <p className="text-xs text-slate-500 mb-1 font-medium">Status</p>
          <p className="text-xl font-bold text-green-600">Optimal</p>
        </div>
      </div>

      <div className="bg-yellow-50 p-5 rounded-2xl flex gap-3 border border-yellow-100">
        <Info className="text-yellow-600 shrink-0" />
        <p className="text-xs text-yellow-800 leading-relaxed font-medium">
          The chart above shows the correlation between your checklist compliance and the reduction in surgical complication risk scores.
        </p>
      </div>
    </div>
  </div>
);

const DoctorCalendarFullView = ({ patient, onBack }: { patient: any; onBack: () => void }) => {
  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const daysInMonth = Array.from({ length: 30 }, (_, i) => i + 1);

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-6 flex items-center gap-4 border-b border-slate-100">
        <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h2 className="text-xl font-display font-bold">Monthly Schedule</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase">{patient.name} • April 2026</p>
        </div>
      </div>

      <div className="p-6 space-y-6 flex-1 overflow-y-auto">
        <div className="grid grid-cols-7 gap-2">
          {weekDays.map(day => (
            <div key={day} className="text-center py-2">
              <p className="text-[10px] font-bold text-slate-400 uppercase">{day}</p>
            </div>
          ))}
          {/* Empty slots for start of month if needed */}
          <div className="col-span-2" /> 
          {daysInMonth.map(day => (
            <div 
              key={day} 
              className={cn(
                "aspect-square rounded-xl border flex flex-col items-center justify-center relative",
                day === 13 ? "bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-100" : "bg-white border-slate-100 text-slate-600"
              )}
            >
              <span className="text-xs font-bold">{day}</span>
              {day < 13 && (
                <div className="flex gap-0.5 mt-1">
                  <div className="w-1 h-1 rounded-full bg-green-500" />
                  <div className="w-1 h-1 rounded-full bg-green-500" />
                </div>
              )}
              {day === 15 && (
                <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-red-500" />
              )}
            </div>
          ))}
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-sm">Legend</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-xs text-slate-600">Tasks Completed</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span className="text-xs text-slate-600">Surgery Date</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-600" />
              <span className="text-xs text-slate-600">Today</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [role, setRole] = useState<Role>(() => {
    if (typeof window !== 'undefined') {
      const hostname = window.location.hostname;
      if (hostname.startsWith('doctor.')) return 'doctor';
    }
    return 'patient';
  });
  const [currentStep, setCurrentStep] = useState<Step>('login');
  const [doctorStep, setDoctorStep] = useState<DoctorStep>('login');
  const [selectedPatient, setSelectedPatient] = useState<any>(null);

  return (
    <div className="relative min-h-screen bg-slate-50 flex items-center justify-center">
      <div className={cn(
        "bg-white min-h-screen shadow-2xl relative overflow-hidden flex flex-col transition-all duration-500",
        role === 'patient' ? "max-w-md w-full" : "max-w-7xl w-full"
      )}>
        {role === 'patient' ? (
          <AnimatePresence mode="wait">
            {currentStep === 'login' && (
              <motion.div
                key="login"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1"
              >
                <LoginScreen 
                  role={role} 
                  setRole={setRole} 
                  onLogin={() => setCurrentStep('empty')} 
                  onRegister={() => setCurrentStep('register')} 
                />
              </motion.div>
            )}

            {currentStep === 'register' && (
              <motion.div
                key="register"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1"
              >
                <RegisterScreen 
                  role={role} 
                  setRole={setRole} 
                  onRegister={() => setCurrentStep('empty')} 
                  onLogin={() => setCurrentStep('login')} 
                />
              </motion.div>
            )}

            {currentStep === 'empty' && (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1"
              >
                <EmptyHomeScreen onOpenMail={() => setCurrentStep('invite')} />
              </motion.div>
            )}

            {currentStep === 'invite' && (
              <motion.div
                key="invite"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex-1"
              >
                <InviteScreen 
                  onAccept={() => setCurrentStep('surgery-details')} 
                  onBack={() => setCurrentStep('empty')}
                />
              </motion.div>
            )}

            {currentStep === 'surgery-details' && (
              <motion.div
                key="surgery-details"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1"
              >
                <SurgeryDetailsScreen onNext={() => setCurrentStep('tnc')} />
              </motion.div>
            )}

            {currentStep === 'tnc' && (
              <motion.div
                key="tnc"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1"
              >
                <TNCScreen onComplete={() => setCurrentStep('dashboard')} />
              </motion.div>
            )}

            {currentStep === 'dashboard' && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="flex-1"
              >
                <DashboardScreen 
                  onShowChecklist={() => setCurrentStep('checklist')} 
                  onShowProgress={() => setCurrentStep('progress')} 
                  onLogout={() => setCurrentStep('login')}
                />
              </motion.div>
            )}

            {currentStep === 'checklist' && (
              <motion.div
                key="checklist"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1"
              >
                <ChecklistScreen onBack={() => setCurrentStep('dashboard')} />
              </motion.div>
            )}

            {currentStep === 'progress' && (
              <motion.div
                key="progress"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="flex-1"
              >
                <ProgressScreen onBack={() => setCurrentStep('dashboard')} />
              </motion.div>
            )}
          </AnimatePresence>
        ) : (
          <AnimatePresence mode="wait">
            {doctorStep === 'login' && (
              <motion.div
                key="doc-login"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1"
              >
                <LoginScreen 
                  role={role} 
                  setRole={setRole} 
                  onLogin={() => setDoctorStep('dashboard')} 
                  onRegister={() => setDoctorStep('register')} 
                />
              </motion.div>
            )}

            {doctorStep === 'register' && (
              <motion.div
                key="doc-register"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1"
              >
                <RegisterScreen 
                  role={role} 
                  setRole={setRole} 
                  onRegister={() => setDoctorStep('dashboard')} 
                  onLogin={() => setDoctorStep('login')} 
                />
              </motion.div>
            )}

            {doctorStep === 'dashboard' && (
              <motion.div
                key="doc-dashboard"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex-1"
              >
                <DoctorDashboardScreen 
                  onSelectPatient={(p) => {
                    setSelectedPatient(p);
                    setDoctorStep('patient-detail');
                  }}
                  onAddPatient={() => setDoctorStep('add-patient')}
                  onLogout={() => setDoctorStep('login')}
                />
              </motion.div>
            )}

            {doctorStep === 'patient-detail' && (
              <motion.div
                key="doc-detail"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex-1"
              >
                <DoctorPatientDetailScreen 
                  patient={selectedPatient} 
                  onBack={() => setDoctorStep('dashboard')} 
                  onExpandCalendar={() => setDoctorStep('calendar-full')}
                />
              </motion.div>
            )}

            {doctorStep === 'calendar-full' && (
              <motion.div
                key="doc-calendar"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="flex-1"
              >
                <DoctorCalendarFullView 
                  patient={selectedPatient} 
                  onBack={() => setDoctorStep('patient-detail')} 
                />
              </motion.div>
            )}

            {doctorStep === 'add-patient' && (
              <motion.div
                key="doc-add"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="flex-1"
              >
                <DoctorAddPatientScreen 
                  onBack={() => setDoctorStep('dashboard')} 
                  onComplete={() => setDoctorStep('dashboard')} 
                />
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
